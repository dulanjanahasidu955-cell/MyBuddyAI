package com.mybuddy.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.widget.*
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import org.json.JSONArray

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var tts: TextToSpeech
    private var sinhala = true
    private val prefs by lazy { getSharedPreferences("mybuddy", MODE_PRIVATE) }
    private val entries by lazy { prefs.getString("entries", "") ?: "" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "🤖 My Buddy"
            textSize = 28f
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "ඔයාගේ පුද්ගලික සහායකයා • Your personal assistant"
            textSize = 15f
        }
        root.addView(subtitle)
        val lang = Button(this).apply {
            text = "සිංහල / English"
            setOnClickListener { sinhala = !sinhala; Toast.makeText(this@MainActivity, if (sinhala) "සිංහල mode" else "English mode", Toast.LENGTH_SHORT).show() }
        }
        root.addView(lang)
        chat = TextView(this).apply {
            text = if (sinhala) "ආයුබෝවන්! මම My Buddy. මට සටහන්, ආදායම්/වියදම්, සහ දෛනික සැලසුම් තබාගන්න උදව් කරන්න පුළුවන්." else "Hello! I'm My Buddy. I can help you keep notes, track income/expenses, and plan your day."
            textSize = 17f
            setPadding(0, 18, 0, 18)
        }
        root.addView(chat)
        input = EditText(this).apply { hint = "මෙතන ලියන්න / Type here" }
        root.addView(input, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply { text = "Send"; setOnClickListener { handle(input.text.toString()); input.setText("") } }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply { text = "🎤"; setOnClickListener { voiceInput() } }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply { text = "🔊"; setOnClickListener { tts.speak(chat.text.toString(), TextToSpeech.QUEUE_FLUSH, null, "buddy") } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(Button(this).apply { text = "➕ Save note / සටහනක්"; setOnClickListener { saveNote() } })
        actions.addView(Button(this).apply { text = "💰 Add income / expense"; setOnClickListener { addMoney() } })
        actions.addView(Button(this).apply { text = "📋 View records / වාර්තා"; setOnClickListener { showRecords() } })
        actions.addView(Button(this).apply { text = "🏍️ PickMe profit calculator"; setOnClickListener { pickMeCalculator() } })
        actions.addView(Button(this).apply { text = "🎯 My goals & profile"; setOnClickListener { setMyGoals() } })
        actions.addView(Button(this).apply { text = "🧠 Set up AI Chat"; setOnClickListener { setAiKey() } })
        actions.addView(Button(this).apply { text = "🗓 Daily plan / දවසේ සැලැස්ම"; setOnClickListener { handle(if (sinhala) "දවසේ සැලැස්ම" else "daily plan") } })
        root.addView(actions)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun handle(text: String) {
        if (text.isBlank()) return
        val lower = text.lowercase()
        when {
            lower.contains("plan") || text.contains("සැලැස්ම") -> {
                val reply = if (sinhala) "අද සැලැස්ම:\n1. අද කළ යුතු වැඩ 3ක් ලියන්න.\n2. වැදගත් වැඩ මුලින් කරන්න.\n3. දවස අවසානයේ ආදායම්/වියදම් සටහන් කරන්න." else "Today's plan:\n1. Write down your top 3 tasks.\n2. Do the most important one first.\n3. Record income and expenses at day's end."
                chat.text = reply
                tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "buddyreply")
            }
            lower.contains("help") || text.contains("උදව්") -> {
                val reply = if (sinhala) "මට සටහන්, ආදායම්/වියදම්, හඬ input, සැලැස්ම් සහ AI chat සඳහා උදව් කළ හැකියි." else "I can help with notes, income/expenses, voice input, planning, and AI chat."
                chat.text = reply
                tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "buddyreply")
            }
            else -> askAi(text)
        }
    }

    private fun setAiKey() {
        val field = EditText(this).apply {
            hint = "Gemini API key"
            setText(prefs.getString("gemini_key", "") ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("Set up AI Chat")
            .setMessage("Internet required. The key is stored on this phone, but app-stored keys are not fully secure. Never publish this project with your key.")
            .setView(field)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", field.text.toString().trim()).apply()
                Toast.makeText(this, "AI key saved on this phone", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askAi(prompt: String) {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isBlank()) {
            chat.text = if (sinhala) "AI Chat සඳහා මුලින් 'Set up AI Chat' ඔබලා Gemini API key එකක් දාන්න." else "Tap 'Set up AI Chat' and enter a Gemini API key first."
            return
        }
        chat.text = if (sinhala) "My Buddy හිතමින් ඉන්නවා..." else "My Buddy is thinking..."
        Thread {
            var answer = ""
            var error = ""
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + key)
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
                val parts = JSONArray().put(JSONObject().put("text", "You are My Buddy, a helpful bilingual Sinhala-English personal assistant. Reply in the language the user uses, warmly and clearly. User message: $prompt"))
                val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
                val body = JSONObject().put("contents", contents).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (code in 200..299) {
                    answer = JSONObject(response).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                } else {
                    error = "AI request failed (HTTP $code). Check API key, internet, and provider quota."
                }
            } catch (e: Exception) {
                error = "Couldn't connect to AI. Check internet and API key."
            } finally {
                conn?.disconnect()
            }
            Handler(Looper.getMainLooper()).post {
                chat.text = if (answer.isNotBlank()) answer else error
                if (answer.isNotBlank()) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "buddyai")
            }
        }.start()
    }

    private fun voiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (sinhala) "si-LK" else "en-US")
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (sinhala) "කතා කරන්න" else "Speak now")
            }
            startActivityForResult(intent, 101)
        } catch (_: Exception) {
            Toast.makeText(this, "Voice input isn't available on this phone", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { input.setText(spoken); handle(spoken) }
        }
    }

    private fun saveNote() {
        val field = EditText(this).apply { hint = "Note / සටහන" }
        AlertDialog.Builder(this).setTitle("Save note").setView(field)
            .setPositiveButton("Save") { _, _ ->
                val old = prefs.getString("notes", "") ?: ""
                prefs.edit().putString("notes", old + "\n• " + field.text.toString()).apply()
                Toast.makeText(this, "Saved / සුරැකුවා", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun addMoney() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val amount = EditText(this).apply { hint = "Amount in Rs."; inputType = 2 }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Income / ආදායම", "Expense / වියදම")) }
        val note = EditText(this).apply { hint = "Description / විස්තර" }
        layout.addView(amount); layout.addView(type); layout.addView(note)
        AlertDialog.Builder(this).setTitle("Money record").setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val a = amount.text.toString().toDoubleOrNull()
                if (a != null && a > 0) {
                    val kind = if (type.selectedItemPosition == 0) "INCOME" else "EXPENSE"
                    val old = prefs.getString("money", "") ?: ""
                    prefs.edit().putString("money", old + "\n$kind | Rs. $a | ${note.text}").apply()
                    Toast.makeText(this, "Saved / සුරැකුවා", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun setMyGoals() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val goal = EditText(this).apply {
            hint = "Monthly savings goal (Rs.)"
            inputType = 2
            setText(prefs.getString("monthly_goal", "") ?: "")
        }
        val daily = EditText(this).apply {
            hint = "Daily PickMe income target (Rs.)"
            inputType = 2
            setText(prefs.getString("daily_target", "") ?: "")
        }
        val note = EditText(this).apply {
            hint = "Other goal / note (e.g. key money)"
            setText(prefs.getString("goal_note", "") ?: "")
        }
        layout.addView(goal); layout.addView(daily); layout.addView(note)
        AlertDialog.Builder(this).setTitle("🎯 My goals & profile").setView(layout)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("monthly_goal", goal.text.toString())
                    .putString("daily_target", daily.text.toString())
                    .putString("goal_note", note.text.toString())
                    .apply()
                val reply = "Saved goals:\\nMonthly savings: Rs. ${goal.text}\\nDaily PickMe target: Rs. ${daily.text}\\nNote: ${note.text}"
                chat.text = reply
                Toast.makeText(this@MainActivity, "Goals saved on this phone", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun pickMeCalculator() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val gross = EditText(this).apply { hint = "Total PickMe income (Rs.)"; inputType = 2 }
        val fuel = EditText(this).apply { hint = "Fuel used (litres)"; inputType = 8194 }
        val price = EditText(this).apply { hint = "Petrol price per litre (default 415)"; inputType = 2; setText("415") }
        val maintenance = EditText(this).apply { hint = "Daily maintenance (default 150)"; inputType = 2; setText("150") }
        layout.addView(gross); layout.addView(fuel); layout.addView(price); layout.addView(maintenance)
        AlertDialog.Builder(this).setTitle("🏍️ PickMe profit calculator").setView(layout)
            .setPositiveButton("Calculate") { _, _ ->
                val income = gross.text.toString().toDoubleOrNull()
                val litres = fuel.text.toString().toDoubleOrNull()
                val petrolPrice = price.text.toString().toDoubleOrNull() ?: 415.0
                val upkeep = maintenance.text.toString().toDoubleOrNull() ?: 150.0
                if (income != null && litres != null && income >= 0 && litres >= 0) {
                    val fuelCost = litres * petrolPrice
                    val profit = income - fuelCost - upkeep
                    val result = "Gross income: Rs. ${"%.2f".format(income)}\\nFuel cost: Rs. ${"%.2f".format(fuelCost)}\\nMaintenance: Rs. ${"%.2f".format(upkeep)}\\nEstimated net: Rs. ${"%.2f".format(profit)}"
                    AlertDialog.Builder(this@MainActivity).setTitle("Daily result").setMessage(result)
                        .setPositiveButton("Save record") { _, _ ->
                            val old = prefs.getString("money", "") ?: ""
                            prefs.edit().putString("money", old + "\\nPICKME | income Rs. $income | fuel Rs. $fuelCost | maintenance Rs. $upkeep | net Rs. $profit").apply()
                            Toast.makeText(this@MainActivity, "Saved / සුරැකුවා", Toast.LENGTH_SHORT).show()
                        }.setNegativeButton("Close", null).show()
                } else Toast.makeText(this, "Enter valid income and litres", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showRecords() {
        val notes = prefs.getString("notes", "No notes yet") ?: "No notes yet"
        val money = prefs.getString("money", "No money records yet") ?: "No money records yet"
        val goals = "Monthly savings goal: Rs. ${prefs.getString(\"monthly_goal\", \"not set\")}\\nDaily income target: Rs. ${prefs.getString(\"daily_target\", \"not set\")}\\nGoal note: ${prefs.getString(\"goal_note\", \"not set\")}"
        AlertDialog.Builder(this).setTitle("My Buddy records")
            .setMessage("NOTES\n$notes\n\nINCOME / EXPENSE\n$money")
            .setPositiveButton("OK", null).show()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("si", "LK")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}

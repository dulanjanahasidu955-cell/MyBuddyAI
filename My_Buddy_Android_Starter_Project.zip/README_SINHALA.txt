MY BUDDY - Android starter project

මෙය Android Studio project source code එකකි. දැනට සූදානම් APK එකක් නොවේ.

දැනට ඇති පහසුකම්:
- සිංහල / English UI toggle
- Voice input (phone එකේ speech recognition support තිබිය යුතුයි)
- Text-to-speech
- Local notes
- Income / expense records
- Simple daily plan replies

ඊළඟ අදියර: සම්පූර්ණ AI chat + APK
---------------------------------
මෙම source project එකේ full online AI chat එක තවම සම්බන්ධ කර නැත.
AI chat සඳහා AI provider එකක API access එකක් සහ internet/network code එකක් අවශ්‍ය වේ.
API key එකක් chat එකට, screenshots වලට හෝ public GitHub repository එකකට දාන්න එපා.
Android app එක තුළ API key එක ගබඩා කිරීමෙන්ද key එක extract කරගැනීමේ අවදානමක් තිබේ.
ආරක්ෂිතව භාවිත කිරීමට private backend එකක් හරහා API call කිරීම වඩා හොඳයි; ඒකට hosting/configuration අවශ්‍ය විය හැක.

APK build කිරීමට:
1. Android Studio එකෙන් මෙම folder එක open කරන්න.
2. Gradle sync සම්පූර්ණ වීමට ඉඩ දෙන්න.
3. Build > Build APK(s) තෝරන්න.
4. app/build/outputs/apk/debug/app-debug.apk යන තැන APK එක ලැබේ.

සටහන: මේ ZIP එක source project එකක් පමණි; install කරන්න පුළුවන් APK එකක් නොවේ.

අලුත් කරපු පහසුකම:
- PickMe profit calculator: දවසේ මුළු ආදායම, භාවිත කළ petrol litres, petrol price සහ maintenance දාලා estimated net profit ගණනය කරයි.
- Default petrol price Rs. 415/L සහ daily maintenance Rs. 150; අවශ්‍ය නම් වෙනස් කරන්න.

අලුත් කරපු පහසුකම:
- My goals & profile: මාසික ඉතිරි කිරීමේ ඉලක්කය, දෛනික PickMe ආදායම් ඉලක්කය සහ වෙනත් ඉලක්කයක් phone එකේ local ලෙස save කරයි.
- මේවා cloud එකකට sync නොවේ; app data clear කළොත් හෝ app එක uninstall කළොත් නැතිවිය හැක.

AI Chat එකට අලුත් පහසුකම:
- Set up AI Chat button එකෙන් Gemini API key එක phone එකට දාන්න.
- Internet connection අවශ්‍යයි. API provider එකේ free quota/limits තිබිය හැක; ඒවා වෙනස් විය හැක.
- API key එක app එකේ local storage එකේ තැබීම සම්පූර්ණයෙන් ආරක්ෂිත නොවේ. මේ project එක public GitHub එකකට key එක සමඟ upload කරන්න එපා.
- Google AI Studio හරහා API key එකක් ලබාගන්න: https://aistudio.google.com/app/apikey
